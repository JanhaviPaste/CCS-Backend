package com.cg.springRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditCardSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
