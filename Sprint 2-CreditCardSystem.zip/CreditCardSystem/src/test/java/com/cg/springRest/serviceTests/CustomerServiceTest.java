package com.cg.springRest.serviceTests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.cg.springRest.model.Customer;
import com.cg.springRest.model.User;
import com.cg.springRest.repository.CustomerRepository;
import com.cg.springRest.service.CustomerService;
import com.cg.springRest.service.CustomerServiceImplementation;

/**
 * This class contains the methods to addCustomer and getCustomerById method.
 * 
 * @author Deepali
 *
 */
@SpringBootTest
public class CustomerServiceTest {

	@Autowired
	CustomerServiceImplementation service;

	@MockBean
	CustomerRepository repository;

	CustomerService listMock = mock(CustomerService.class, "myMock");

	/**
	 * This method will test the addCustomer method.
	 * 
	 * @param customer:{@link Customer}
	 * 
	 */
	@Test
	public void addCustomerTest() {
		User user = new User(2, "adkale", "aditya", 2);
		Customer cust = new Customer("Aditya Kale", "9834938517", "adi19@gmail.com", user);
		when(repository.save(cust)).thenReturn(cust);
		assertEquals(cust, service.addCustomer(cust));
	}

	/**
	 * This method will test the getCustomerById method.
	 * 
	 * @param email:{@link Customer}
	 * 
	 */
	@Test
	public void getCustomerById() {
		String Email = "adi19@gmail.com";
		User user = new User(2, "adkale", "aditya", 2);
		Customer customer = new Customer("Aditya Kale", "adi19@gmail.com", "9123456789", user);
		when(repository.findById(Email)).thenReturn(Optional.of(customer));
		assertEquals(customer.getCustomerName(), "Aditya Kale");
	}
}
