package com.cg.springRest.serviceTests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.cg.springRest.model.CreditCard;
import com.cg.springRest.model.Transaction;
import com.cg.springRest.repository.TransactionRepository;
import com.cg.springRest.service.TransactionService;
import com.cg.springRest.service.TransactionServiceImplementation;

/**
 * This class contains methods to test the get transaction details method.
 * 
 * @author Janhavi
 *
 */
@SpringBootTest
public class TransactionServiceTest {

	@Autowired
	TransactionServiceImplementation service;

	@MockBean
	TransactionRepository repository;

	//TransactionService listMock = mock(TransactionService.class, "myMock");

	/**
	 * This method will test the getTransactionDetails method.
	 * 
	 * @param creditCardNumber:{@link CreditCard}
	 * 
	 */
	
	@Test
	public void getTransactionsDetails() {
		long credit = 253;
		List<Transaction> listTransactions = Stream.of(new Transaction("Credit Card", 35000, new Date(), 253),
				new Transaction("Credit Card", 20000, new Date(), 243)).collect(Collectors.toList());
		when(repository.findAllByCreditCardNumber(credit)).thenReturn(listTransactions);
		assertEquals(repository.findAllByCreditCardNumber(credit).get(0).getcreditCardNumber(), credit);
	}

}