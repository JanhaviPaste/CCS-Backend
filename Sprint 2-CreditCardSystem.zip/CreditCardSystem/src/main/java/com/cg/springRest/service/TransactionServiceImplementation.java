package com.cg.springRest.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springRest.model.Transaction;
import com.cg.springRest.repository.TransactionRepository;

/**
 * This class includes methods to get all the transactions based on the credit card number.
 * 
 * @author Janhavi
 *
 */
@Service
@Transactional
public class TransactionServiceImplementation implements TransactionService {

	@Autowired
	TransactionRepository transRepository;

	/**
	 * This method accepts the credit card number and returns a list of transactions.
	 * The list of transactions can be downloaded by the customer.
	 * 
	 * @param creditCardNumber:{@link CreditCard}
	 * @return {@link ResponseEntity}:{@link Optional}:creditCardNumber{@link CreditCard}
	 */
	public List<Transaction> getTransactionDetails(long creditCardNumber) {
		return transRepository.findAllByCreditCardNumber(creditCardNumber);
	}

}