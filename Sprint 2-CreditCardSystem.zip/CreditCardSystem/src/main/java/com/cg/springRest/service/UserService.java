package com.cg.springRest.service;

import java.util.List;
import java.util.Optional;

import com.cg.springRest.model.User;

/**
 * 
 * @author Samiksha
 *
 */
public interface UserService {

	public User getAdmin(int id);
	
	public List<User> getAllUsers();

	public User addAdmin(User user);
	
	public Optional<User> deleteAdmin(int id);

	
}