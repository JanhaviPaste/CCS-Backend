package com.cg.springRest.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springRest.model.CreditCard;
import com.cg.springRest.repository.CreditCardRepository;
import com.cg.springRest.repository.UserRepository;

/**
 * This class contains methods to buy credit card based on customer salary and to get the credit card details based on credit card number.
 * 
 * @author Anushka
 */

@Service
@Transactional

public class CreditCardServiceImplementation implements CreditCardService {

	@Autowired
	CreditCardRepository creditRepository;
	
	@Autowired
	UserRepository userRepository;
	
	/**
     * This method will accept a credit card number.
     * It will return an object of CreditCard containing the details of the credit card.
     * 
     * @param creditNo:{@link CreditCard}
     * @return {@link ResponseEntity}:credit card:{@link CreditCard}
     * @throws Exception
     */
	@Override
	public CreditCard getCreditDetails(long creditNo) {
		return creditRepository.findById(creditNo).orElse(null);
	}

	/**
     * This method will accept the monthly salary and customer id of the customer.
     * This will initially check if the customer id entered is valid.
     * Based on the monthly salary the customer will be assigned a credit card of a appropriate type. 
     * 
     * @param salary:{@link CreditCard}
     * @param id:{@link Customer}
     * @param creditCard:{@link CreditCard}
     * @return {@link ResponseEntity}:credit card:{@link CreditCard}
     */
	@Override
	public CreditCard buyCreditCard(double salary, CreditCard creditCard) {
		return creditRepository.save(creditCard);
	}

	

}