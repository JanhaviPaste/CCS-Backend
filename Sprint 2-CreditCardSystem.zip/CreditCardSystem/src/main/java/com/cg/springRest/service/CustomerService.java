package com.cg.springRest.service;

import com.cg.springRest.model.Customer;

/**
 * 
 * @author Deepali
 *
 */
public interface CustomerService {
	
	public Customer addCustomer(Customer customer);
	 
	public Customer getCustomerById(String email);
}