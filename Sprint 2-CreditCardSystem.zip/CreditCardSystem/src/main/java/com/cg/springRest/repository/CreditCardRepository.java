package com.cg.springRest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.springRest.model.CreditCard;

/**
 * 
 * @author Anushka
 * 
 *         This inteface has a method that gives the details of credit card
 *         based on the credit card number.
 *
 */

@Repository
public interface CreditCardRepository extends JpaRepository<CreditCard, Long> {

	/**
	 * This method accepts the credit card number and returns credit card details
	 * 
	 * @param creditCardNumber:{@link CreditCard}
	 * @return Credit Card Details
	 */
	public CreditCard findByCreditcardNo(long creditCardNumber);

}