package com.cg.springRest.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springRest.model.User;
import com.cg.springRest.repository.UserRepository;

/**
 * This class includes methods to login, logout, add an admin, delete an admin, get all the users and get list of all the admins.
 * 
 * @author Samiksha 
 *
 */

@Service
@Transactional
public class UserServiceImplementation implements UserService {

	@Autowired
	UserRepository repository;
	
	/**
	 * This method will add an admin into the table.
	 * It will return an object of User that has been added into the table.
	 * 
	 * @param user:{@link User}
	 * @return user:{@link User}
	 */
	public User addAdmin(User user) {
		return repository.save(user);
	}

	/**
	 *This method will accept the user id and will return an admin associated with it.
	 *Return an object of User i.e the admin 
	 *
	 * @param id:{@link User}
	 * @return user:{@link User}
	 * @throws Exception
	 */
	public User getAdmin(int id) {
		return repository.findById(id).orElse(null);
	}

	/**
	 * This method will give a list of all the users i.e the admins and customers in the table.
	 * This will return a list of users.
	 * 
	 * @return {@link ResponseEntity}:{@link List}:user{@link User}
	 * @throws Exception
	 */
	public List<User> getAllUsers() {
		return repository.findAll();
	}

	/**
	 * This method will accept the user id and delete the admin associated with it.
	 * Return an object of user that contains the deleted admin.
	 * 
	 * @param id{@link User}
	 * @return {@link ResponseEntity}:{@link Optional}:user{@link User}
	 */
	public Optional<User> deleteAdmin(int id) {
		repository.deleteById(id);
		return repository.findById(id);
	}

	

}