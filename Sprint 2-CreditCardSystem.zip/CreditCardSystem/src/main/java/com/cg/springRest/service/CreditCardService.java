package com.cg.springRest.service;

import com.cg.springRest.model.CreditCard;

/**
 * 
 * @author Anushka
 *
 */
public interface CreditCardService {

	public CreditCard getCreditDetails(long creditNo);

	public CreditCard buyCreditCard(double salary, CreditCard creditCard);

	

}