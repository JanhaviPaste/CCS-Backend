package com.cg.springRest.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springRest.model.Customer;
import com.cg.springRest.repository.CustomerRepository;

/**
 * Contains method to register customer and to get the customer details based on emailId of the customer.
 * 
 * @author Deepali
 *
 */
@Service
@Transactional
public class CustomerServiceImplementation implements CustomerService {

	@Autowired
	CustomerRepository custRepository;

	/**
     * This method will ask the user to register and will save these details.
     * 
     * @param customer:{@link Customer}
     * @return customer:{@link Customer}
     */
	public Customer addCustomer(Customer customer) {
		return custRepository.save(customer);
	}

	/**
     * This method will show all the details of the customer based on the email.
     * 
     * @param email:{@link Customer}
     * @return {@link ResponseEntity}:customers:{@link Customer}
     * @throws Exception
     */
	  public Customer getCustomerById(String email) { 
		  return custRepository.findById(email).orElse(null); }
	 
}