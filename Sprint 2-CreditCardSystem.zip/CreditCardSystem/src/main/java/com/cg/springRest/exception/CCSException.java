package com.cg.springRest.exception;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

/**
 * This class contain customized exception CustomerNotFoundException. It throws
 * an exception with customized message.
 * 
 * @author Janhavi
 *
 */
@ControllerAdvice
public class CCSException {

	/**
	 * @param exception:{@link CustomerNotFoundException}
	 * @param request:{@link   WebRequest}
	 * @return {@link ResponseEntity}:Error Details:{@link ErrorDetails}
	 */
	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<ErrorDetails> handleException(CustomerNotFoundException exception, WebRequest request) {
		ErrorDetails details = new ErrorDetails(exception.getMessage(), LocalDate.now(), request.getDescription(false));
		return new ResponseEntity<ErrorDetails>(details, HttpStatus.NOT_FOUND);
	}

	/**
	 * @param exception:{@link Exception}
	 * @param request:{@link   WebRequest}
	 * @return {@link ResponseEntity}: Object:{@link object}
	 */
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(Exception exception, WebRequest request) {
		ErrorDetails details = new ErrorDetails(exception.getMessage(), LocalDate.now(), request.getDescription(false));
		return new ResponseEntity<Object>(details, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * @param ex:{@link      MethodArgumentNotValidException }
	 * @param headers:{@link HttpHeaders}
	 * @param status:{@link  HttpStatus}
	 * @param request:{@link WebRequest}
	 * @return {@link ResponseEntity} Object:{@link object}
	 */
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getFieldErrors()
				.forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));
		return new ResponseEntity<Object>(errors, HttpStatus.BAD_REQUEST);
	}
}
