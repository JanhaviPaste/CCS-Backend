package com.cg.springRest.controller;

public enum Status {
	SUCCESS,
    USER_ALREADY_EXISTS,
    FAILURE
}