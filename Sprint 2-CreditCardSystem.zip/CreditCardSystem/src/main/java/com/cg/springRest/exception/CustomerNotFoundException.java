package com.cg.springRest.exception;

/**
 * This class contain customized exception CustomerNotFoundException which
 * extends RuntimeException. It contain default and parameterized constructor.
 * It throws an exception with customized message.
 * 
 * @author Janhavi
 *
 */
@SuppressWarnings("serial")
public class CustomerNotFoundException extends RuntimeException{

	public CustomerNotFoundException() {
	
	}
	public CustomerNotFoundException(String message) {
		super(message);
	}
}
